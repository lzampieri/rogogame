<!DOCTYPE html>
<html lang="it-it">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Pagina di prova</title>

        <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
        <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>

        @inertiaHead
    </head>
    <body>
        @inertia
    </body>
</html>
<?php /**PATH D:\web_design\rogogame\resources\views/home.blade.php ENDPATH**/ ?>