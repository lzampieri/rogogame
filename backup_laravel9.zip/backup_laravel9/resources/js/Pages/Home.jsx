import React from 'react';
import { Link } from '@inertiajs/inertia-react';

export default function Home(props) {
    return (
        <>
            <Link href={route('about')}>Logout</Link> <br />
            Base url: { props.baseURL } <br />
            Request url: { props.requestURL } <br />
        </>
    )
}