import React from 'react';
import { Link } from '@inertiajs/inertia-react';

export default function About(props) {
    return (
        <>
            About
        </>
    )
}