<!DOCTYPE html>
<html lang="it-it">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Pagina di prova</title>

        @routes

        @viteReactRefresh
        @vite('resources/js/app.jsx')

        @inertiaHead
    </head>
    <body>
        @inertia
    </body>
</html>
