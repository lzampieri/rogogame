Ho cambiato
'url' => $request->getBaseUrl().$request->getRequestUri(),
in
'url' => $request->fullUrl(),
nel file
vendor\inertiajs\inertia-laravel\src\Response.php